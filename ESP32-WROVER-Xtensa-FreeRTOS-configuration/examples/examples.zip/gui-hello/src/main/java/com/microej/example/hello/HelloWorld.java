/*
 * Java
 *
 * Copyright 2016 IS2T. All rights reserved.
 * For demonstration purpose only.
 * IS2T PROPRIETARY. Use is subject to license terms.
 */
package com.microej.example.hello;

import java.io.IOException;

import ej.microui.MicroUI;
import ej.microui.display.Colors;
import ej.microui.display.Display;
import ej.microui.display.Displayable;
import ej.microui.display.Font;
import ej.microui.display.GraphicsContext;
import ej.microui.display.Image;
import ej.microui.util.EventHandler;

/**
 * Prints the message "Hello World !" an displays MicroEJ splash
 */
public class HelloWorld extends Displayable implements EventHandler{

	private static final int PADDING_TEXT 					= 5;
	private static final int PADDING_BETWEEN_IMAGE_AND_TEXT = 30;

	private final String[] messages;

	private Image microejImage;

	public static void main(String[] args) {
		MicroUI.start();
		new HelloWorld().show();
		System.out.println("Hello World !");
	}

	public HelloWorld() {
		super(Display.getDefaultDisplay());
		messages = new String[]{ "Hello" };
		try {
			microejImage = Image.createImage("/images/microej.png");
		}
		catch (IOException e) {
			throw new AssertionError(e);
		}
	}

	@Override
	public void paint(GraphicsContext g) {
		// clean
		g.setColor(Colors.WHITE);
		int width = getDisplay().getWidth();
		int height = getDisplay().getHeight();
		g.fillRect(0, 0, width, height);

		// compute vertical center
		int y = height / 2;
		int microejImageHeight = microejImage.getHeight();
		y -= (microejImageHeight + PADDING_BETWEEN_IMAGE_AND_TEXT) / 2;
		Font font = Font.getFont(Font.LATIN, 26, Font.STYLE_PLAIN);
		g.setFont(font);
		y -= (messages.length*font.getHeight() + PADDING_TEXT) / 2;

		// draw MicroEJ image
		g.drawImage(microejImage, width / 2, y, GraphicsContext.HCENTER | GraphicsContext.TOP);
		y += microejImageHeight + PADDING_BETWEEN_IMAGE_AND_TEXT;

		// draw each message
		g.setColor(Colors.NAVY);
		for (String message : this.messages) {
			g.drawString(message, width / 2, y, GraphicsContext.HCENTER | GraphicsContext.VCENTER);
			y += font.getHeight() + PADDING_TEXT;
		}
	}

	@Override
	public EventHandler getController() {
		return this;
	}

	@Override
	public boolean handleEvent(int event) {
		return false;
	}
}
